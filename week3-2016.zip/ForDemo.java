// Demonstrate the for loop.
class ForDemo
{
  public static void main(String[] args)
  {
    char ch;
    // print the alphabet using a for loop
    for(ch = 'a'; ch <= 'z'; ch++)
    {
      System.out.print(ch);
    }
  }
}